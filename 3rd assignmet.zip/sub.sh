#!/bin/bash
read -p "enter the first number: " num1
read -p "enter the second: " num2
sub=$(($num1-$num2))


echo "Sub is: $sub"
