#!/bin/bash


read -p"enter number 1: " num1
read -p"enter the second number: " num2
read -p"enter the third number: " num2
if [[  $num1 -gt $num2  &&  $num1 -gt $num3  ]]
then 
	echo $num1
elif [[  $num2 -gt $num1  &&  $num2 -gt $num3  ]]
then
	echo $num2
else
	echo $num3
fi
